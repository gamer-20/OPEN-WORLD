OPEN WORLD — Offline Starter Prototype

HOW TO PLAY
1. Extract the ZIP file.
2. Open index.html in a modern desktop browser (Chrome, Edge, or Firefox).
3. No internet connection is required.
4. Use W/A/S/D or the arrow keys to drive. Press R to reset.

WHAT THIS IS
This is a small, offline 2D top-down driving prototype with a city grid,
buildings, moving traffic, pedestrians, and basic driving physics.

It is NOT a finished 3D game and does not have GTA 6-level graphics.
A large realistic 3D open-world game requires a game engine (such as Unreal
Engine or Unity), original art/audio, and substantial development.
